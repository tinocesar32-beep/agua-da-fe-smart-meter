// Função serverless (Vercel). Corre no servidor, nunca no telemóvel,
// para que a chave da API da Anthropic nunca seja exposta ao cliente.
// Configure a variável de ambiente ANTHROPIC_API_KEY no projeto Vercel.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Método não permitido" });
    return;
  }

  const { base64, mediaType } = req.body || {};
  if (!base64 || !mediaType) {
    res.status(400).json({ error: "Imagem em falta no pedido" });
    return;
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    res.status(500).json({ error: "ANTHROPIC_API_KEY não está configurada no servidor" });
    return;
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 300,
        system:
          "És um especialista em leitura de contadores de água mecânicos e digitais. Analisa a fotografia e devolve APENAS um objeto JSON válido, sem markdown, sem texto adicional, no formato exato: {\"leitura\": <número decimal em m3 com 3 casas, ex: 88.800>, \"confianca\": \"alta\"|\"media\"|\"baixa\", \"observacoes\": \"<nota curta em português, ex: dígitos parcialmente visíveis>\"}. Os dígitos pretos representam metros cúbicos inteiros; os dígitos vermelhos ou o ponteiro representam a fração decimal do m3. Combina ambos num único número decimal.",
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } },
              { type: "text", text: "Lê este contador de água e devolve o JSON pedido." },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Anthropic API error:", errText);
      res.status(502).json({ error: "Falha ao contactar o serviço de IA" });
      return;
    }

    const json = await response.json();
    const textBlock = (json.content || []).find((b) => b.type === "text");
    if (!textBlock) {
      res.status(502).json({ error: "Sem resposta de texto da IA" });
      return;
    }

    const clean = textBlock.text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    if (typeof parsed.leitura !== "number") {
      throw new Error("Formato inesperado na resposta da IA");
    }

    res.status(200).json(parsed);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Não foi possível analisar a fotografia" });
  }
}
