import { get, set } from "idb-keyval";

// Toda a informação (leituras, vendas, configuração) fica guardada
// localmente no telemóvel/computador, dentro do IndexedDB do browser.
// Nada sai daqui exceto a fotografia enviada para /api/analyze.
const KEY = "agua-da-fe:data";

export async function loadData() {
  try {
    const value = await get(KEY);
    return value ?? null;
  } catch {
    return null;
  }
}

export async function saveData(data) {
  try {
    await set(KEY, data);
    return true;
  } catch {
    return false;
  }
}
