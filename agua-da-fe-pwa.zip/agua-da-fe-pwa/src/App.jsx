import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
  Droplets, Camera, Upload, Loader2, CheckCircle2, AlertTriangle,
  TrendingUp, Package, Gauge, Wallet, Factory,
  Plus, Settings, LayoutDashboard, FileBarChart,
  ScanLine, Calendar, X, Trash2, Waves
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Area, AreaChart
} from "recharts";
import { loadData, saveData } from "./db.js";

/* ---------------------------------------------------------------
   Água da Fé · Smart Meter (PWA)
   Dados guardados localmente no dispositivo (IndexedDB).
   A leitura por foto chama /api/analyze (função serverless na Vercel).
----------------------------------------------------------------*/

const BOTTLES = [
  { key: "20", label: "Garrafão 20 L", liters: 20, unit: "garrafão" },
  { key: "6", label: "Garrafa 6 L", liters: 6, unit: "garrafa" },
  { key: "5", label: "Garrafa 5 L", liters: 5, unit: "garrafa" },
  { key: "1.5", label: "Garrafa 1,5 L", liters: 1.5, unit: "garrafa" },
];

const DEFAULT_CONFIG = {
  prices: { "20": 400, "6": 150, "5": 130, "1.5": 50 },
  costs: { "20": 150, "6": 60, "5": 50, "1.5": 20 },
  minStock: { "20": 50, "6": 100, "5": 100, "1.5": 200 },
  avgConsumptionThreshold: 5,
  dailyRevenueTarget: 100000,
  wasteFactor: 0.05,
};

const KZ = (n) =>
  (Math.round(n * 100) / 100).toLocaleString("pt-PT", { maximumFractionDigits: 0 }) + " Kz";
const fmt = (n, d = 0) => (n ?? 0).toLocaleString("pt-PT", { maximumFractionDigits: d, minimumFractionDigits: d });
const todayKey = (d = new Date()) => d.toISOString().slice(0, 10);
const isoWeekKey = (d) => {
  const dt = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = dt.getUTCDay() || 7;
  dt.setUTCDate(dt.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(dt.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((dt - yearStart) / 86400000 + 1) / 7);
  return `${dt.getUTCFullYear()}-S${String(week).padStart(2, "0")}`;
};
const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const yearKey = (d) => `${d.getFullYear()}`;
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`);

/* ---------------- Meter dial: physical odometer readout ---------------- */
function MeterDial({ value }) {
  const v = Math.max(0, Number(value) || 0);
  const [intPart, fracPart] = v.toFixed(3).split(".");
  const intDigits = intPart.padStart(3, "0").split("");
  const fracDigits = fracPart.split("");
  const dims = { w: 30, h: 40, fs: 22 };
  const Wheel = ({ d, red }) => (
    <div
      style={{
        width: dims.w, height: dims.h,
        background: red ? "linear-gradient(180deg,#4a1613,#2a0b09)" : "linear-gradient(180deg,#f4efe4,#dcd4bf)",
        color: red ? "#ff8a75" : "#161311",
        fontFamily: "'IBM Plex Mono', monospace", fontSize: dims.fs, fontWeight: 600,
        display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 3,
        boxShadow: red ? "inset 0 2px 3px rgba(0,0,0,.6), 0 1px 0 rgba(255,255,255,.05)" : "inset 0 -2px 3px rgba(0,0,0,.25), inset 0 2px 2px rgba(255,255,255,.6)",
        border: red ? "1px solid #200907" : "1px solid #b8ad8f",
      }}
    >
      {d}
    </div>
  );
  return (
    <div className="flex items-end gap-[3px]" aria-label={`Leitura ${v} metros cúbicos`}>
      {intDigits.map((d, i) => <Wheel key={"i" + i} d={d} />)}
      <div style={{ fontFamily: "'IBM Plex Mono', monospace" }} className="mx-1 self-center text-2xl font-bold text-[#5fd9c9]">m³</div>
      {fracDigits.map((d, i) => <Wheel key={"f" + i} d={d} red />)}
    </div>
  );
}

function Card({ children, className = "" }) {
  return (
    <div className={`rounded-xl p-5 ${className}`} style={{ background: "linear-gradient(165deg,#0f2b36,#0b212a)", border: "1px solid rgba(95,217,201,0.12)" }}>
      {children}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sub, tone = "aqua" }) {
  const tones = { aqua: "#5fd9c9", amber: "#f2a93b", red: "#f0665a", white: "#eaf6f6" };
  return (
    <Card className="flex flex-col gap-2 min-w-0">
      <div className="flex items-center gap-2" style={{ color: "#7fa3ac" }}>
        <Icon size={15} />
        <span className="text-[11px] uppercase tracking-[0.12em]">{label}</span>
      </div>
      <div style={{ fontFamily: "'IBM Plex Mono', monospace", color: tones[tone] }} className="text-2xl font-semibold truncate">{value}</div>
      {sub && <div className="text-xs" style={{ color: "#5c8089" }}>{sub}</div>}
    </Card>
  );
}

function Field({ label, children }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[11px] uppercase tracking-[0.1em]" style={{ color: "#7fa3ac" }}>{label}</span>
      {children}
    </label>
  );
}

const inputStyle = { background: "#0a2028", border: "1px solid rgba(95,217,201,0.2)", color: "#eaf6f6" };

function TextInput(props) {
  return (
    <input {...props} style={inputStyle} className={`rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 ring-[#5fd9c9]/40 ${props.className || ""}`} />
  );
}

function Btn({ children, onClick, variant = "primary", disabled, type = "button", className = "" }) {
  const base = "rounded-lg px-4 py-2 text-sm font-semibold flex items-center justify-center gap-2 transition disabled:opacity-40 disabled:cursor-not-allowed";
  const styles = {
    primary: { background: "#5fd9c9", color: "#04211d" },
    ghost: { background: "transparent", color: "#5fd9c9", border: "1px solid rgba(95,217,201,0.35)" },
    danger: { background: "rgba(240,102,90,0.15)", color: "#f0665a", border: "1px solid rgba(240,102,90,0.4)" },
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${className}`} style={styles[variant]}>
      {children}
    </button>
  );
}

function AlertPill({ level, children }) {
  const colors = {
    danger: { bg: "rgba(240,102,90,0.12)", bd: "rgba(240,102,90,0.4)", fg: "#f0665a" },
    warn: { bg: "rgba(242,169,59,0.12)", bd: "rgba(242,169,59,0.4)", fg: "#f2a93b" },
  };
  const c = colors[level];
  return (
    <div className="flex items-start gap-2 rounded-lg px-3 py-2.5 text-sm" style={{ background: c.bg, border: `1px solid ${c.bd}`, color: c.fg }}>
      <AlertTriangle size={16} className="mt-0.5 shrink-0" />
      <span>{children}</span>
    </div>
  );
}

/* ================= MAIN APP ================= */
export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("leitura");
  const [saveErr, setSaveErr] = useState(false);

  useEffect(() => {
    (async () => {
      const stored = await loadData();
      setData(stored || { readings: [], sales: [], config: DEFAULT_CONFIG });
      setLoading(false);
    })();
  }, []);

  const persist = useCallback(async (next) => {
    setData(next);
    const ok = await saveData(next);
    setSaveErr(!ok);
  }, []);

  const readings = data?.readings || [];
  const sales = data?.sales || [];
  const config = data?.config || DEFAULT_CONFIG;
  const lastReading = readings[readings.length - 1] || null;

  const addReading = (entry) => persist({ ...data, readings: [...readings, entry] });
  const deleteReading = (id) => persist({ ...data, readings: readings.filter((r) => r.id !== id) });
  const addSale = (entry) => persist({ ...data, sales: [...sales, entry] });
  const deleteSale = (id) => persist({ ...data, sales: sales.filter((s) => s.id !== id) });
  const updateConfig = (next) => persist({ ...data, config: next });

  const today = todayKey();
  const todaysReadings = readings.filter((r) => r.date === today);
  const todaysReading = todaysReadings[todaysReadings.length - 1] || null;
  const consumptionTodayM3 = todaysReadings.reduce((s, r) => s + r.consumptionM3, 0);
  const consumptionTodayL = consumptionTodayM3 * 1000;
  const perdas = consumptionTodayL * config.wasteFactor;
  const litrosDisponiveis = consumptionTodayL - perdas;
  const eficiencia = consumptionTodayL > 0 ? (litrosDisponiveis / consumptionTodayL) * 100 : 0;

  const capacity = useMemo(() => {
    const out = {};
    BOTTLES.forEach((b) => (out[b.key] = Math.floor(litrosDisponiveis / b.liters)));
    return out;
  }, [litrosDisponiveis]);

  const todaysSales = sales.filter((s) => s.date === today);
  const soldToday = useMemo(() => {
    const out = { "20": 0, "6": 0, "5": 0, "1.5": 0 };
    todaysSales.forEach((s) => BOTTLES.forEach((b) => (out[b.key] += s.qty[b.key] || 0)));
    return out;
  }, [todaysSales]);

  const revenueToday = todaysSales.reduce((s, x) => s + x.revenue, 0);
  const costToday = todaysSales.reduce((s, x) => s + x.cost, 0);
  const profitToday = revenueToday - costToday;

  const avg7 = useMemo(() => {
    const last7 = readings.slice(-8, -1);
    if (!last7.length) return config.avgConsumptionThreshold;
    return last7.reduce((s, r) => s + r.consumptionM3, 0) / last7.length;
  }, [readings, config.avgConsumptionThreshold]);

  const alerts = useMemo(() => {
    const list = [];
    if (consumptionTodayM3 > avg7 * 1.3 && consumptionTodayM3 > 0) {
      list.push({ level: "danger", text: `Consumo de hoje (${fmt(consumptionTodayM3, 1)} m³) está ${fmt(((consumptionTodayM3 / avg7) - 1) * 100, 0)}% acima da média dos últimos 7 dias — possível fuga de água.` });
    }
    BOTTLES.forEach((b) => {
      const remaining = capacity[b.key] - soldToday[b.key];
      if (remaining < 0) {
        list.push({ level: "warn", text: `Vendeu mais ${b.label} do que a produção do dia permite (défice de ${fmt(Math.abs(remaining))}) — produção insuficiente para a procura.` });
      } else if (remaining < config.minStock[b.key]) {
        list.push({ level: "warn", text: `Stock projetado de ${b.label} (${fmt(remaining)}) abaixo do mínimo definido (${fmt(config.minStock[b.key])}).` });
      }
    });
    if (todaysSales.length > 0 && revenueToday < config.dailyRevenueTarget) {
      list.push({ level: "warn", text: `Receita de hoje (${KZ(revenueToday)}) está abaixo da meta diária (${KZ(config.dailyRevenueTarget)}).` });
    }
    return list;
  }, [consumptionTodayM3, avg7, capacity, soldToday, config, todaysSales, revenueToday]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#071b24" }}>
        <Loader2 className="animate-spin" style={{ color: "#5fd9c9" }} size={28} />
      </div>
    );
  }

  const NAV = [
    { id: "leitura", label: "Leitura", icon: ScanLine },
    { id: "vendas", label: "Vendas", icon: Package },
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "relatorios", label: "Relatórios", icon: FileBarChart },
    { id: "config", label: "Configuração", icon: Settings },
  ];

  return (
    <div className="min-h-screen w-full pb-24 md:pb-8" style={{ background: "radial-gradient(ellipse at top,#0d2933,#071b24 60%)", color: "#eaf6f6", fontFamily: "'Manrope', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; }
        ::-webkit-scrollbar { height: 6px; width: 6px; }
        ::-webkit-scrollbar-thumb { background: rgba(95,217,201,0.25); border-radius: 4px; }
        @keyframes flow { 0% { stroke-dashoffset: 0; } 100% { stroke-dashoffset: -40; } }
        .flow-line { stroke-dasharray: 6 6; animation: flow 1.8s linear infinite; }
      `}</style>

      <header className="px-5 md:px-8 pt-6 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: "rgba(95,217,201,0.12)", border: "1px solid rgba(95,217,201,0.3)" }}>
            <Droplets size={20} color="#5fd9c9" />
          </div>
          <div>
            <div className="text-[17px] font-extrabold tracking-tight leading-none">Água da Fé</div>
            <div className="text-[11px] uppercase tracking-[0.14em]" style={{ color: "#5c8089" }}>Smart Meter</div>
          </div>
        </div>
        <svg width="90" height="20" viewBox="0 0 90 20" className="hidden sm:block opacity-70">
          <path d="M0 10 Q 11 0, 22 10 T 44 10 T 66 10 T 90 10" stroke="#5fd9c9" strokeWidth="1.5" fill="none" className="flow-line" />
        </svg>
      </header>

      <nav className="hidden md:flex gap-1 px-8 mb-6">
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setTab(n.id)} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition"
            style={{ background: tab === n.id ? "rgba(95,217,201,0.14)" : "transparent", color: tab === n.id ? "#5fd9c9" : "#7fa3ac" }}>
            <n.icon size={15} /> {n.label}
          </button>
        ))}
        {saveErr && <span className="ml-auto self-center text-xs text-[#f0665a]">Falha ao guardar localmente</span>}
      </nav>

      <main className="px-5 md:px-8">
        {tab === "leitura" && <LeituraTab lastReading={lastReading} addReading={addReading} readings={readings} deleteReading={deleteReading} />}
        {tab === "vendas" && <VendasTab config={config} addSale={addSale} sales={sales} deleteSale={deleteSale} capacity={capacity} soldToday={soldToday} hasReadingToday={!!todaysReading} />}
        {tab === "dashboard" && (
          <DashboardTab consumptionTodayM3={consumptionTodayM3} consumptionTodayL={consumptionTodayL} perdas={perdas} eficiencia={eficiencia}
            revenueToday={revenueToday} profitToday={profitToday} capacity={capacity} soldToday={soldToday} alerts={alerts} readings={readings} />
        )}
        {tab === "relatorios" && <RelatoriosTab readings={readings} sales={sales} />}
        {tab === "config" && <ConfigTab config={config} updateConfig={updateConfig} />}
      </main>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 flex justify-around py-2 px-2" style={{ background: "#0b212a", borderTop: "1px solid rgba(95,217,201,0.15)" }}>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setTab(n.id)} className="flex flex-col items-center gap-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold" style={{ color: tab === n.id ? "#5fd9c9" : "#5c8089" }}>
            <n.icon size={18} />
            {n.label}
          </button>
        ))}
      </nav>
    </div>
  );
}

/* ================= LEITURA TAB ================= */
function LeituraTab({ lastReading, addReading, readings, deleteReading }) {
  const fileRef = useRef(null);
  const [preview, setPreview] = useState(null);
  const [fileData, setFileData] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState(null);
  const [error, setError] = useState(null);
  const [manualReading, setManualReading] = useState("");
  const [dt, setDt] = useState(() => new Date().toISOString().slice(0, 16));

  const onFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAiResult(null); setError(null); setManualReading("");
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      const base64 = result.split(",")[1];
      setFileData({ base64, mediaType: file.type || "image/jpeg" });
      setPreview(result);
    };
    reader.readAsDataURL(file);
  };

  const analyze = async () => {
    if (!fileData) return;
    setAnalyzing(true); setError(null);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ base64: fileData.base64, mediaType: fileData.mediaType }),
      });
      const parsed = await response.json();
      if (!response.ok || parsed.error) throw new Error(parsed.error || "Erro desconhecido");
      setAiResult(parsed);
      setManualReading(String(parsed.leitura));
    } catch (e) {
      setError("Não foi possível ler a fotografia automaticamente. Introduza a leitura manualmente.");
    } finally {
      setAnalyzing(false);
    }
  };

  const current = parseFloat(manualReading);
  const previous = lastReading ? lastReading.currentReading : null;
  const consumption = previous !== null && !isNaN(current) ? current - previous : null;
  const validConsumption = consumption !== null && consumption >= 0;

  const save = () => {
    if (isNaN(current)) return;
    const cons = previous !== null ? current - previous : 0;
    const entry = {
      id: uid(),
      timestamp: new Date(dt).toISOString(),
      date: dt.slice(0, 10),
      currentReading: current,
      previousReading: previous ?? current,
      consumptionM3: Math.max(0, cons),
      consumptionL: Math.max(0, cons) * 1000,
      source: aiResult ? "foto" : "manual",
      confidence: aiResult?.confianca || null,
      note: aiResult?.observacoes || "",
    };
    addReading(entry);
    setPreview(null); setFileData(null); setAiResult(null); setManualReading(""); setError(null);
  };

  return (
    <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-5">
      <Card>
        <div className="flex items-center gap-2 mb-4" style={{ color: "#7fa3ac" }}>
          <Camera size={16} />
          <span className="text-[11px] uppercase tracking-[0.12em]">Nova leitura por fotografia</span>
        </div>

        {!preview && (
          <button onClick={() => fileRef.current?.click()} className="w-full h-48 rounded-xl flex flex-col items-center justify-center gap-2 transition"
            style={{ border: "2px dashed rgba(95,217,201,0.3)", background: "rgba(95,217,201,0.03)", color: "#5fd9c9" }}>
            <Upload size={24} />
            <span className="text-sm font-semibold">Tirar ou carregar fotografia do contador</span>
            <span className="text-xs" style={{ color: "#5c8089" }}>JPG ou PNG</span>
          </button>
        )}
        <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={onFile} />

        {preview && (
          <div className="space-y-4">
            <div className="relative rounded-xl overflow-hidden" style={{ border: "1px solid rgba(95,217,201,0.2)" }}>
              <img src={preview} alt="Contador" className="w-full max-h-64 object-cover" />
              <button onClick={() => { setPreview(null); setFileData(null); setAiResult(null); setError(null); }}
                className="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(7,27,36,0.85)", color: "#eaf6f6" }}>
                <X size={14} />
              </button>
            </div>

            {!aiResult && (
              <Btn onClick={analyze} disabled={analyzing} className="w-full">
                {analyzing ? <Loader2 size={16} className="animate-spin" /> : <ScanLine size={16} />}
                {analyzing ? "A analisar…" : "Analisar com IA"}
              </Btn>
            )}

            {aiResult && (
              <div className="flex items-start gap-2 rounded-lg px-3 py-2.5 text-sm" style={{ background: "rgba(95,217,201,0.1)", border: "1px solid rgba(95,217,201,0.3)", color: "#5fd9c9" }}>
                <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
                <span>Leitura detetada: <b>{fmt(aiResult.leitura, 3)} m³</b> · confiança {aiResult.confianca}{aiResult.observacoes ? ` — ${aiResult.observacoes}` : ""}. Confirme ou corrija abaixo.</span>
              </div>
            )}
            {error && <AlertPill level="warn">{error}</AlertPill>}
          </div>
        )}
      </Card>

      <Card>
        <div className="flex items-center gap-2 mb-4" style={{ color: "#7fa3ac" }}>
          <Gauge size={16} />
          <span className="text-[11px] uppercase tracking-[0.12em]">Confirmar leitura</span>
        </div>

        <div className="flex justify-center mb-5 overflow-x-auto py-2">
          <MeterDial value={isNaN(current) ? 0 : current} />
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <Field label="Leitura atual (m³)">
            <TextInput type="number" step="0.001" value={manualReading} onChange={(e) => setManualReading(e.target.value)} placeholder="88.800" />
          </Field>
          <Field label="Data e hora">
            <TextInput type="datetime-local" value={dt} onChange={(e) => setDt(e.target.value)} />
          </Field>
        </div>

        <div className="rounded-lg p-3 mb-4 text-sm space-y-1.5" style={{ background: "#0a2028" }}>
          <div className="flex justify-between"><span style={{ color: "#7fa3ac" }}>Leitura anterior</span><span>{previous !== null ? `${fmt(previous, 3)} m³` : "— (primeira leitura)"}</span></div>
          <div className="flex justify-between">
            <span style={{ color: "#7fa3ac" }}>Consumo</span>
            <span style={{ color: validConsumption ? "#5fd9c9" : "#f0665a" }}>{consumption !== null ? `${fmt(consumption, 3)} m³ (${fmt(consumption * 1000)} L)` : "—"}</span>
          </div>
        </div>
        {consumption !== null && consumption < 0 && <AlertPill level="danger">A leitura atual é inferior à anterior. Verifique o valor introduzido.</AlertPill>}

        <Btn onClick={save} disabled={isNaN(current) || (consumption !== null && consumption < 0)} className="w-full mt-4">
          <Plus size={16} /> Guardar leitura
        </Btn>
      </Card>

      {readings.length > 0 && (
        <Card className="lg:col-span-2">
          <div className="flex items-center gap-2 mb-3" style={{ color: "#7fa3ac" }}>
            <Calendar size={16} />
            <span className="text-[11px] uppercase tracking-[0.12em]">Histórico de leituras</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ color: "#5c8089" }} className="text-left">
                  <th className="pb-2 font-medium">Data</th>
                  <th className="pb-2 font-medium">Leitura</th>
                  <th className="pb-2 font-medium">Consumo</th>
                  <th className="pb-2 font-medium">Origem</th>
                  <th className="pb-2 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {[...readings].reverse().map((r) => (
                  <tr key={r.id} style={{ borderTop: "1px solid rgba(95,217,201,0.08)" }}>
                    <td className="py-2">{new Date(r.timestamp).toLocaleString("pt-PT", { dateStyle: "short", timeStyle: "short" })}</td>
                    <td className="py-2" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>{fmt(r.currentReading, 3)} m³</td>
                    <td className="py-2" style={{ color: "#5fd9c9" }}>{fmt(r.consumptionM3, 3)} m³</td>
                    <td className="py-2 capitalize" style={{ color: "#5c8089" }}>{r.source}</td>
                    <td className="py-2 text-right"><button onClick={() => deleteReading(r.id)} style={{ color: "#5c8089" }}><Trash2 size={14} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

/* ================= VENDAS TAB ================= */
function VendasTab({ config, addSale, sales, deleteSale, capacity, soldToday, hasReadingToday }) {
  const [qty, setQty] = useState({ "20": "", "6": "", "5": "", "1.5": "" });
  const [date, setDate] = useState(todayKey());

  const revenue = BOTTLES.reduce((s, b) => s + (parseFloat(qty[b.key]) || 0) * config.prices[b.key], 0);
  const cost = BOTTLES.reduce((s, b) => s + (parseFloat(qty[b.key]) || 0) * config.costs[b.key], 0);
  const anyQty = BOTTLES.some((b) => parseFloat(qty[b.key]) > 0);

  const save = () => {
    const q = {};
    BOTTLES.forEach((b) => (q[b.key] = parseFloat(qty[b.key]) || 0));
    addSale({ id: uid(), date, timestamp: new Date().toISOString(), qty: q, revenue, cost });
    setQty({ "20": "", "6": "", "5": "", "1.5": "" });
  };

  return (
    <div className="grid lg:grid-cols-[1fr_0.9fr] gap-5">
      <Card>
        <div className="flex items-center gap-2 mb-4" style={{ color: "#7fa3ac" }}>
          <Package size={16} />
          <span className="text-[11px] uppercase tracking-[0.12em]">Registar vendas do dia</span>
        </div>

        {!hasReadingToday && <div className="mb-4"><AlertPill level="warn">Ainda não há leitura do contador para hoje — a capacidade de produção não pode ser confirmada.</AlertPill></div>}

        <Field label="Data"><TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mb-4" /></Field>

        <div className="space-y-3 mt-3">
          {BOTTLES.map((b) => {
            const remaining = capacity[b.key] - soldToday[b.key];
            return (
              <div key={b.key} className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="text-sm font-semibold">{b.label}</div>
                  <div className="text-xs" style={{ color: "#5c8089" }}>Preço {KZ(config.prices[b.key])} · capacidade restante hoje: {fmt(Math.max(0, remaining))}</div>
                </div>
                <TextInput type="number" min="0" placeholder="0" value={qty[b.key]} onChange={(e) => setQty({ ...qty, [b.key]: e.target.value })} className="w-24 text-right" />
              </div>
            );
          })}
        </div>

        <div className="rounded-lg p-3 mt-4 text-sm space-y-1.5" style={{ background: "#0a2028" }}>
          <div className="flex justify-between"><span style={{ color: "#7fa3ac" }}>Receita</span><span style={{ color: "#5fd9c9" }}>{KZ(revenue)}</span></div>
          <div className="flex justify-between"><span style={{ color: "#7fa3ac" }}>Custo estimado</span><span>{KZ(cost)}</span></div>
          <div className="flex justify-between font-semibold"><span>Lucro</span><span style={{ color: "#5fd9c9" }}>{KZ(revenue - cost)}</span></div>
        </div>

        <Btn onClick={save} disabled={!anyQty} className="w-full mt-4"><Plus size={16} /> Registar venda</Btn>
      </Card>

      <Card>
        <div className="flex items-center gap-2 mb-3" style={{ color: "#7fa3ac" }}>
          <Wallet size={16} />
          <span className="text-[11px] uppercase tracking-[0.12em]">Vendas registadas</span>
        </div>
        <div className="space-y-2 max-h-[520px] overflow-y-auto">
          {[...sales].reverse().map((s) => (
            <div key={s.id} className="rounded-lg p-3 flex items-center justify-between" style={{ background: "#0a2028" }}>
              <div>
                <div className="text-sm font-semibold">{new Date(s.timestamp).toLocaleDateString("pt-PT")}</div>
                <div className="text-xs" style={{ color: "#5c8089" }}>{BOTTLES.filter((b) => s.qty[b.key] > 0).map((b) => `${s.qty[b.key]}× ${b.key}L`).join(" · ") || "sem itens"}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold" style={{ color: "#5fd9c9" }}>{KZ(s.revenue)}</span>
                <button onClick={() => deleteSale(s.id)} style={{ color: "#5c8089" }}><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
          {sales.length === 0 && <div className="text-sm" style={{ color: "#5c8089" }}>Ainda sem vendas registadas.</div>}
        </div>
      </Card>
    </div>
  );
}

/* ================= DASHBOARD TAB ================= */
function DashboardTab({ consumptionTodayM3, consumptionTodayL, perdas, eficiencia, revenueToday, profitToday, capacity, soldToday, alerts, readings }) {
  const chartData = useMemo(() => readings.slice(-14).map((r) => ({
    date: new Date(r.timestamp).toLocaleDateString("pt-PT", { day: "2-digit", month: "2-digit" }),
    consumo: Math.round(r.consumptionM3 * 100) / 100,
  })), [readings]);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={Gauge} label="Consumo diário" value={`${fmt(consumptionTodayM3, 2)} m³`} sub={`${fmt(consumptionTodayL)} L`} />
        <StatCard icon={Factory} label="Água produzida" value={`${fmt(consumptionTodayL - perdas)} L`} sub={`eficiência ${fmt(eficiencia, 0)}%`} tone="aqua" />
        <StatCard icon={TrendingUp} label="Receita" value={KZ(revenueToday)} tone="white" />
        <StatCard icon={Wallet} label={profitToday >= 0 ? "Lucro" : "Prejuízo"} value={KZ(Math.abs(profitToday))} tone={profitToday >= 0 ? "aqua" : "red"} />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <div className="flex items-center gap-2 mb-1" style={{ color: "#7fa3ac" }}><Droplets size={15} /><span className="text-[11px] uppercase tracking-[0.12em]">Perdas de água hoje</span></div>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", color: "#f2a93b" }} className="text-2xl font-semibold">{fmt(perdas)} L</div>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-1" style={{ color: "#7fa3ac" }}><Package size={15} /><span className="text-[11px] uppercase tracking-[0.12em]">Total vendido hoje</span></div>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace" }} className="text-2xl font-semibold">{BOTTLES.reduce((s, b) => s + soldToday[b.key], 0)} <span className="text-sm font-normal" style={{ color: "#5c8089" }}>unidades</span></div>
        </Card>
      </div>

      <Card>
        <div className="flex items-center gap-2 mb-3" style={{ color: "#7fa3ac" }}><Waves size={15} /><span className="text-[11px] uppercase tracking-[0.12em]">Capacidade de enchimento hoje</span></div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {BOTTLES.map((b) => (
            <div key={b.key} className="rounded-lg p-3" style={{ background: "#0a2028" }}>
              <div className="text-xs" style={{ color: "#5c8089" }}>{b.label}</div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", color: "#5fd9c9" }} className="text-xl font-semibold">{fmt(capacity[b.key])}</div>
              <div className="text-xs mt-0.5" style={{ color: soldToday[b.key] > capacity[b.key] ? "#f0665a" : "#5c8089" }}>{soldToday[b.key]} vendidas</div>
            </div>
          ))}
        </div>
      </Card>

      {chartData.length > 1 && (
        <Card>
          <div className="flex items-center gap-2 mb-3" style={{ color: "#7fa3ac" }}><TrendingUp size={15} /><span className="text-[11px] uppercase tracking-[0.12em]">Consumo — últimas leituras</span></div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="fillC" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#5fd9c9" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#5fd9c9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(95,217,201,0.08)" />
              <XAxis dataKey="date" tick={{ fill: "#5c8089", fontSize: 11 }} />
              <YAxis tick={{ fill: "#5c8089", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#0b212a", border: "1px solid rgba(95,217,201,0.3)", borderRadius: 8, color: "#eaf6f6" }} />
              <Area type="monotone" dataKey="consumo" stroke="#5fd9c9" fill="url(#fillC)" strokeWidth={2} name="Consumo (m³)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
      )}

      <Card>
        <div className="flex items-center gap-2 mb-3" style={{ color: "#7fa3ac" }}><AlertTriangle size={15} /><span className="text-[11px] uppercase tracking-[0.12em]">Alertas inteligentes</span></div>
        {alerts.length === 0 ? (
          <div className="text-sm flex items-center gap-2" style={{ color: "#5fd9c9" }}><CheckCircle2 size={15} /> Tudo dentro do normal.</div>
        ) : (
          <div className="space-y-2">{alerts.map((a, i) => <AlertPill key={i} level={a.level}>{a.text}</AlertPill>)}</div>
        )}
      </Card>
    </div>
  );
}

/* ================= RELATÓRIOS TAB ================= */
function RelatoriosTab({ readings, sales }) {
  const [period, setPeriod] = useState("diario");
  const groupKeyFn = { diario: (d) => todayKey(d), semanal: (d) => isoWeekKey(d), mensal: (d) => monthKey(d), anual: (d) => yearKey(d) }[period];

  const grouped = useMemo(() => {
    const map = {};
    readings.forEach((r) => {
      const k = groupKeyFn(new Date(r.timestamp));
      map[k] = map[k] || { key: k, consumo: 0, receita: 0, custo: 0 };
      map[k].consumo += r.consumptionM3;
    });
    sales.forEach((s) => {
      const k = groupKeyFn(new Date(s.timestamp));
      map[k] = map[k] || { key: k, consumo: 0, receita: 0, custo: 0 };
      map[k].receita += s.revenue;
      map[k].custo += s.cost;
    });
    return Object.values(map).sort((a, b) => (a.key < b.key ? 1 : -1));
  }, [readings, sales, period]);

  const totals = grouped.reduce((acc, g) => ({ consumo: acc.consumo + g.consumo, receita: acc.receita + g.receita, custo: acc.custo + g.custo }), { consumo: 0, receita: 0, custo: 0 });
  const chartData = [...grouped].reverse().slice(-12);

  return (
    <div className="space-y-5">
      <div className="flex gap-2 flex-wrap">
        {[{ id: "diario", label: "Diário" }, { id: "semanal", label: "Semanal" }, { id: "mensal", label: "Mensal" }, { id: "anual", label: "Anual" }].map((p) => (
          <button key={p.id} onClick={() => setPeriod(p.id)} className="px-4 py-1.5 rounded-full text-sm font-semibold"
            style={{ background: period === p.id ? "rgba(95,217,201,0.16)" : "transparent", color: period === p.id ? "#5fd9c9" : "#7fa3ac", border: "1px solid rgba(95,217,201,0.2)" }}>
            {p.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <StatCard icon={Gauge} label="Consumo total" value={`${fmt(totals.consumo, 1)} m³`} />
        <StatCard icon={TrendingUp} label="Receita total" value={KZ(totals.receita)} />
        <StatCard icon={Wallet} label="Lucro total" value={KZ(totals.receita - totals.custo)} tone={totals.receita - totals.custo >= 0 ? "aqua" : "red"} />
      </div>

      {chartData.length > 0 && (
        <Card>
          <div className="text-[11px] uppercase tracking-[0.12em] mb-3" style={{ color: "#7fa3ac" }}>Receita por período</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(95,217,201,0.08)" />
              <XAxis dataKey="key" tick={{ fill: "#5c8089", fontSize: 10 }} />
              <YAxis tick={{ fill: "#5c8089", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#0b212a", border: "1px solid rgba(95,217,201,0.3)", borderRadius: 8, color: "#eaf6f6" }} />
              <Bar dataKey="receita" fill="#5fd9c9" radius={[4, 4, 0, 0]} name="Receita (Kz)" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ color: "#5c8089" }} className="text-left">
                <th className="pb-2 font-medium">Período</th>
                <th className="pb-2 font-medium">Consumo</th>
                <th className="pb-2 font-medium">Receita</th>
                <th className="pb-2 font-medium">Lucro</th>
              </tr>
            </thead>
            <tbody>
              {grouped.map((g) => (
                <tr key={g.key} style={{ borderTop: "1px solid rgba(95,217,201,0.08)" }}>
                  <td className="py-2">{g.key}</td>
                  <td className="py-2">{fmt(g.consumo, 2)} m³</td>
                  <td className="py-2" style={{ color: "#5fd9c9" }}>{KZ(g.receita)}</td>
                  <td className="py-2">{KZ(g.receita - g.custo)}</td>
                </tr>
              ))}
              {grouped.length === 0 && <tr><td colSpan={4} className="py-6 text-center" style={{ color: "#5c8089" }}>Sem dados ainda — registe leituras e vendas para gerar relatórios.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ================= CONFIG TAB ================= */
function ConfigTab({ config, updateConfig }) {
  const [local, setLocal] = useState(config);
  const [saved, setSaved] = useState(false);

  useEffect(() => setLocal(config), [config]);

  const setPrice = (key, v) => setLocal({ ...local, prices: { ...local.prices, [key]: parseFloat(v) || 0 } });
  const setCost = (key, v) => setLocal({ ...local, costs: { ...local.costs, [key]: parseFloat(v) || 0 } });
  const setMinStock = (key, v) => setLocal({ ...local, minStock: { ...local.minStock, [key]: parseFloat(v) || 0 } });

  const save = () => {
    updateConfig(local);
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  };

  return (
    <div className="grid lg:grid-cols-2 gap-5">
      <Card>
        <div className="text-[11px] uppercase tracking-[0.12em] mb-4" style={{ color: "#7fa3ac" }}>Preços de venda (Kz)</div>
        <div className="space-y-3">
          {BOTTLES.map((b) => (
            <div key={b.key} className="flex items-center justify-between gap-3">
              <span className="text-sm">{b.label}</span>
              <TextInput type="number" value={local.prices[b.key]} onChange={(e) => setPrice(b.key, e.target.value)} className="w-28 text-right" />
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="text-[11px] uppercase tracking-[0.12em] mb-4" style={{ color: "#7fa3ac" }}>Custo de produção (Kz/unidade)</div>
        <div className="space-y-3">
          {BOTTLES.map((b) => (
            <div key={b.key} className="flex items-center justify-between gap-3">
              <span className="text-sm">{b.label}</span>
              <TextInput type="number" value={local.costs[b.key]} onChange={(e) => setCost(b.key, e.target.value)} className="w-28 text-right" />
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="text-[11px] uppercase tracking-[0.12em] mb-4" style={{ color: "#7fa3ac" }}>Stock mínimo (unidades)</div>
        <div className="space-y-3">
          {BOTTLES.map((b) => (
            <div key={b.key} className="flex items-center justify-between gap-3">
              <span className="text-sm">{b.label}</span>
              <TextInput type="number" value={local.minStock[b.key]} onChange={(e) => setMinStock(b.key, e.target.value)} className="w-28 text-right" />
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="text-[11px] uppercase tracking-[0.12em] mb-4" style={{ color: "#7fa3ac" }}>Alertas e produção</div>
        <div className="space-y-4">
          <Field label="Limite de consumo médio (m³/dia) para alerta de fuga">
            <TextInput type="number" step="0.1" value={local.avgConsumptionThreshold} onChange={(e) => setLocal({ ...local, avgConsumptionThreshold: parseFloat(e.target.value) || 0 })} />
          </Field>
          <Field label="Meta de receita diária (Kz)">
            <TextInput type="number" value={local.dailyRevenueTarget} onChange={(e) => setLocal({ ...local, dailyRevenueTarget: parseFloat(e.target.value) || 0 })} />
          </Field>
          <Field label="Fator de perdas na produção (%)">
            <TextInput type="number" step="1" value={Math.round(local.wasteFactor * 100)} onChange={(e) => setLocal({ ...local, wasteFactor: (parseFloat(e.target.value) || 0) / 100 })} />
          </Field>
        </div>
      </Card>

      <div className="lg:col-span-2">
        <Btn onClick={save} className="w-fit">{saved ? <CheckCircle2 size={16} /> : <Settings size={16} />} {saved ? "Guardado" : "Guardar configuração"}</Btn>
      </div>
    </div>
  );
}
